
  # Restaurant application

  This is a code bundle for Restaurant application. The original project is available at https://www.figma.com/design/G50uGxijycIvSUjNDzYkRM/Restaurant-application.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  