import { format } from 'date-fns';
import { CheckCircle, Calendar, Clock, Users, User, Mail, Phone, MessageSquare } from 'lucide-react';
import type { Reservation } from '../App';

interface ReservationConfirmationProps {
  reservation: Reservation;
  onNewReservation: () => void;
}

export function ReservationConfirmation({ reservation, onNewReservation }: ReservationConfirmationProps) {
  return (
    <div className="bg-card rounded-lg shadow-xl p-8 max-w-2xl mx-auto">
      <div className="text-center mb-8">
        <div className="inline-flex items-center justify-center w-16 h-16 bg-primary/10 rounded-full mb-4">
          <CheckCircle className="w-10 h-10 text-primary" />
        </div>
        <h2 className="mb-2">Reservation Confirmed!</h2>
        <p className="text-muted-foreground">
          We look forward to serving you at La Cuisine Elegante
        </p>
      </div>

      <div className="space-y-6 mb-8">
        <div className="bg-muted/30 p-6 rounded-lg space-y-4">
          <div className="flex items-start gap-3">
            <Calendar className="w-5 h-5 text-primary mt-0.5" />
            <div>
              <p className="text-sm text-muted-foreground">Date</p>
              <p className="font-medium">{format(reservation.date, 'EEEE, MMMM d, yyyy')}</p>
            </div>
          </div>

          <div className="flex items-start gap-3">
            <Clock className="w-5 h-5 text-primary mt-0.5" />
            <div>
              <p className="text-sm text-muted-foreground">Time</p>
              <p className="font-medium">{reservation.time}</p>
            </div>
          </div>

          <div className="flex items-start gap-3">
            <Users className="w-5 h-5 text-primary mt-0.5" />
            <div>
              <p className="text-sm text-muted-foreground">Party Size</p>
              <p className="font-medium">{reservation.partySize} {reservation.partySize === 1 ? 'Guest' : 'Guests'}</p>
            </div>
          </div>
        </div>

        <div className="border-t border-border pt-6 space-y-4">
          <h3>Guest Information</h3>

          <div className="flex items-start gap-3">
            <User className="w-5 h-5 text-muted-foreground mt-0.5" />
            <div>
              <p className="text-sm text-muted-foreground">Name</p>
              <p>{reservation.name}</p>
            </div>
          </div>

          <div className="flex items-start gap-3">
            <Mail className="w-5 h-5 text-muted-foreground mt-0.5" />
            <div>
              <p className="text-sm text-muted-foreground">Email</p>
              <p>{reservation.email}</p>
            </div>
          </div>

          <div className="flex items-start gap-3">
            <Phone className="w-5 h-5 text-muted-foreground mt-0.5" />
            <div>
              <p className="text-sm text-muted-foreground">Phone</p>
              <p>{reservation.phone}</p>
            </div>
          </div>

          {reservation.specialRequests && (
            <div className="flex items-start gap-3">
              <MessageSquare className="w-5 h-5 text-muted-foreground mt-0.5" />
              <div>
                <p className="text-sm text-muted-foreground">Special Requests</p>
                <p>{reservation.specialRequests}</p>
              </div>
            </div>
          )}
        </div>
      </div>

      <div className="bg-accent/50 p-4 rounded-lg mb-6">
        <p className="text-sm text-center">
          A confirmation email has been sent to <span className="font-medium">{reservation.email}</span>
        </p>
      </div>

      <div className="text-center text-sm text-muted-foreground mb-6">
        <p>Please arrive 10 minutes before your reservation time.</p>
        <p className="mt-1">For changes or cancellations, please call +233 123456789</p>
      </div>

      <button
        onClick={onNewReservation}
        className="w-full bg-secondary text-secondary-foreground py-3 rounded-lg hover:opacity-90 transition-opacity"
      >
        Make Another Reservation
      </button>
    </div>
  );
}
