import { useState } from 'react';
import { format, addDays, isBefore, startOfDay } from 'date-fns';
import { Calendar, Clock, Users, User, Mail, Phone, MessageSquare } from 'lucide-react';
import { DayPicker } from 'react-day-picker';
import 'react-day-picker/dist/style.css';
import './DatePickerStyles.css';
import type { Reservation } from '../App';

interface ReservationFormProps {
  onComplete: (reservation: Reservation) => void;
}

const TIME_SLOTS = [
  '5:00 PM', '5:30 PM', '6:00 PM', '6:30 PM', '7:00 PM', '7:30 PM',
  '8:00 PM', '8:30 PM', '9:00 PM', '9:30 PM', '10:00 PM', '10:30 PM'
];

const PARTY_SIZES = [1, 2, 3, 4, 5, 6, 7, 8];

export function ReservationForm({ onComplete }: ReservationFormProps) {
  const [currentStep, setCurrentStep] = useState(1);
  const [selectedDate, setSelectedDate] = useState<Date>();
  const [selectedTime, setSelectedTime] = useState<string>('');
  const [partySize, setPartySize] = useState<number>(2);
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [specialRequests, setSpecialRequests] = useState('');

  const today = startOfDay(new Date());
  const disabledDays = { before: today };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (selectedDate && selectedTime) {
      onComplete({
        date: selectedDate,
        time: selectedTime,
        partySize,
        name,
        email,
        phone,
        specialRequests
      });
    }
  };

  const canProceedToStep2 = selectedDate && selectedTime;
  const canSubmit = canProceedToStep2 && name && email && phone;

  return (
    <div className="bg-card rounded-lg shadow-xl p-8">
      <div className="mb-8">
        <h2 className="mb-2">Make a Reservation</h2>
        <div className="flex gap-2 mt-4">
          <div className={`flex-1 h-1 rounded ${currentStep >= 1 ? 'bg-primary' : 'bg-border'}`} />
          <div className={`flex-1 h-1 rounded ${currentStep >= 2 ? 'bg-primary' : 'bg-border'}`} />
        </div>
        <div className="flex justify-between mt-2 text-sm text-muted-foreground">
          <span>Select Date & Time</span>
          <span>Your Information</span>
        </div>
      </div>

      <form onSubmit={handleSubmit}>
        {currentStep === 1 && (
          <div className="space-y-8">
            <div>
              <div className="flex items-center gap-2 mb-4">
                <Users className="w-5 h-5 text-primary" />
                <label>Party Size</label>
              </div>
              <div className="grid grid-cols-4 sm:grid-cols-8 gap-2">
                {PARTY_SIZES.map(size => (
                  <button
                    key={size}
                    type="button"
                    onClick={() => setPartySize(size)}
                    className={`p-3 rounded-lg border-2 transition-all ${
                      partySize === size
                        ? 'border-primary bg-primary text-primary-foreground'
                        : 'border-border hover:border-primary'
                    }`}
                  >
                    {size}
                  </button>
                ))}
              </div>
            </div>

            <div>
              <div className="flex items-center gap-2 mb-4">
                <Calendar className="w-5 h-5 text-primary" />
                <label>Select Date</label>
              </div>
              <div className="flex justify-center bg-muted/30 rounded-lg p-4">
                <DayPicker
                  mode="single"
                  selected={selectedDate}
                  onSelect={setSelectedDate}
                  disabled={disabledDays}
                  fromDate={today}
                  toDate={addDays(today, 60)}
                  className="rdp-custom"
                />
              </div>
            </div>

            {selectedDate && (
              <div>
                <div className="flex items-center gap-2 mb-4">
                  <Clock className="w-5 h-5 text-primary" />
                  <label>Select Time</label>
                </div>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                  {TIME_SLOTS.map(time => (
                    <button
                      key={time}
                      type="button"
                      onClick={() => setSelectedTime(time)}
                      className={`p-3 rounded-lg border-2 transition-all ${
                        selectedTime === time
                          ? 'border-primary bg-primary text-primary-foreground'
                          : 'border-border hover:border-primary'
                      }`}
                    >
                      {time}
                    </button>
                  ))}
                </div>
              </div>
            )}

            <button
              type="button"
              onClick={() => setCurrentStep(2)}
              disabled={!canProceedToStep2}
              className="w-full bg-primary text-primary-foreground py-3 rounded-lg disabled:opacity-50 disabled:cursor-not-allowed hover:opacity-90 transition-opacity"
            >
              Continue to Guest Information
            </button>
          </div>
        )}

        {currentStep === 2 && (
          <div className="space-y-6">
            <div className="bg-muted/30 p-4 rounded-lg">
              <p className="text-sm text-muted-foreground mb-1">Your Reservation</p>
              <p className="font-medium">
                {format(selectedDate!, 'EEEE, MMMM d, yyyy')} at {selectedTime} for {partySize} {partySize === 1 ? 'guest' : 'guests'}
              </p>
            </div>

            <div>
              <div className="flex items-center gap-2 mb-2">
                <User className="w-5 h-5 text-primary" />
                <label htmlFor="name">Full Name *</label>
              </div>
              <input
                id="name"
                type="text"
                required
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="w-full px-4 py-3 bg-input-background rounded-lg border border-border focus:outline-none focus:ring-2 focus:ring-ring"
                placeholder="John Doe"
              />
            </div>

            <div>
              <div className="flex items-center gap-2 mb-2">
                <Mail className="w-5 h-5 text-primary" />
                <label htmlFor="email">Email Address *</label>
              </div>
              <input
                id="email"
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full px-4 py-3 bg-input-background rounded-lg border border-border focus:outline-none focus:ring-2 focus:ring-ring"
                placeholder="john@example.com"
              />
            </div>

            <div>
              <div className="flex items-center gap-2 mb-2">
                <Phone className="w-5 h-5 text-primary" />
                <label htmlFor="phone">Phone Number *</label>
              </div>
              <input
                id="phone"
                type="tel"
                required
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                className="w-full px-4 py-3 bg-input-background rounded-lg border border-border focus:outline-none focus:ring-2 focus:ring-ring"
                placeholder="(555) 123-4567"
              />
            </div>

            <div>
              <div className="flex items-center gap-2 mb-2">
                <MessageSquare className="w-5 h-5 text-primary" />
                <label htmlFor="requests">Special Requests (Optional)</label>
              </div>
              <textarea
                id="requests"
                value={specialRequests}
                onChange={(e) => setSpecialRequests(e.target.value)}
                className="w-full px-4 py-3 bg-input-background rounded-lg border border-border focus:outline-none focus:ring-2 focus:ring-ring resize-none"
                rows={3}
                placeholder="Allergies, dietary restrictions, special occasions, seating preferences..."
              />
            </div>

            <div className="flex gap-3">
              <button
                type="button"
                onClick={() => setCurrentStep(1)}
                className="flex-1 bg-secondary text-secondary-foreground py-3 rounded-lg hover:opacity-90 transition-opacity"
              >
                Back
              </button>
              <button
                type="submit"
                disabled={!canSubmit}
                className="flex-1 bg-primary text-primary-foreground py-3 rounded-lg disabled:opacity-50 disabled:cursor-not-allowed hover:opacity-90 transition-opacity"
              >
                Confirm Reservation
              </button>
            </div>
          </div>
        )}
      </form>
    </div>
  );
}
