import { useState } from 'react';
import { ReservationForm } from './components/ReservationForm';
import { ReservationConfirmation } from './components/ReservationConfirmation';
import { ImageWithFallback } from './components/ImageWithFallback';
import { UtensilsCrossed } from 'lucide-react';

export interface Reservation {
  date: Date;
  time: string;
  partySize: number;
  name: string;
  email: string;
  phone: string;
  specialRequests?: string;
}

export default function App() {
  const [reservation, setReservation] = useState<Reservation | null>(null);

  const handleReservationComplete = (reservationData: Reservation) => {
    setReservation(reservationData);
  };

  const handleNewReservation = () => {
    setReservation(null);
  };

  return (
    <div className="min-h-screen bg-background">
      <div className="relative h-80 overflow-hidden">
        <ImageWithFallback
          src="https://images.unsplash.com/photo-1653259038915-7cf0b7a4dd6c?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1920"
          alt="Elegant restaurant interior"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-black/60 via-black/40 to-black/70" />
        <div className="absolute inset-0 flex items-center justify-center">
          <div className="text-center text-white">
            <div className="flex items-center justify-center gap-3 mb-4">
              <UtensilsCrossed className="w-12 h-12" />
            </div>
            <h1 className="text-4xl mb-2">La Cuisine Elegante</h1>
            <p className="text-lg opacity-90">Fine Dining Experience</p>
            <p className="text-sm mt-4 opacity-80">Reserve your table today</p>
          </div>
        </div>
      </div>

      <main className="max-w-4xl mx-auto px-4 py-8 -mt-16 relative z-10">
        {reservation ? (
          <ReservationConfirmation
            reservation={reservation}
            onNewReservation={handleNewReservation}
          />
        ) : (
          <ReservationForm onComplete={handleReservationComplete} />
        )}
      </main>

      <footer className="bg-muted text-muted-foreground py-6 px-4 mt-16">
        <div className="max-w-4xl mx-auto text-center text-sm">
          <p>123 Banku Street, Greater Accra</p>
          <p className="mt-1">Open Tuesday - Sunday, 5:00 PM - 11:00 PM</p>
          <p className="mt-1">Phone: +233 123456789</p>
        </div>
      </footer>
    </div>
  );
}