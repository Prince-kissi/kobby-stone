import { useState, ImgHTMLAttributes } from 'react';

export function ImageWithFallback(props: ImgHTMLAttributes<HTMLImageElement>) {
  const [hasError, setHasError] = useState(false);

  if (hasError) {
    return (
      <div
        className="bg-muted flex items-center justify-center text-muted-foreground"
        style={{ width: props.width, height: props.height }}
      >
        Image unavailable
      </div>
    );
  }

  return (
    <img
      {...props}
      onError={() => setHasError(true)}
    />
  );
}
